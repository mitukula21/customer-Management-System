package com.cg.cust.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.cust.bean.CustBean;
import com.cg.cust.dao.CustDaoImpl;
import com.cg.cust.dao.ICustDAO;
import com.cg.cust.exception.CustException;

public class CustServiceImpl implements ICustService{
	
	ICustDAO custDao;

	public String addCustDetails(CustBean cust) throws CustException {
		custDao=new CustDaoImpl();	
		String custSeq;
		custSeq= custDao.addCustDetails(cust);
		return custSeq; 
	}

	
	public CustBean editCustDetails(String  custid,String Fname,String eid) throws CustException {
		CustDaoImpl custDao=new CustDaoImpl();
		int id=Integer.parseInt(custid);
		CustBean bean=null;
		bean=custDao.editCustDetails(id,Fname,eid);
		return bean;
	}

	
	public List<CustBean> retriveAll() throws CustException {
		custDao=new CustDaoImpl();
		List<CustBean> donorList=null;
		donorList=custDao.retriveAllDetails();
		return donorList;
	}
	
	
	public void deleteCustDetails(int custid) throws CustException {
		CustDaoImpl custDao=new CustDaoImpl();
		String id=Integer.toString(custid);
		CustBean bean=null;
		 bean=custDao.deleteCustDetails(id);
		return ;
	}



		
	
	
	public void validateCust(CustBean bean) throws CustException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating Phone Number
		if(!(isValidPhoneNumber(bean.getPhNo()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		
		if(!validationErrors.isEmpty())
			throw new CustException(validationErrors +"");
	}

	public boolean isValidName(String custName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(custName);
		return nameMatcher.matches();
	}
	
	public boolean isValidPhoneNumber(CharSequence i){
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(i);
		return phoneMatcher.matches();
		
	}
	
	public boolean validateDonorId(String custId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(custId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}


	public String logIn(String user) throws CustException {
		CustDaoImpl custDao=new CustDaoImpl();
		String old=custDao.logIn(user);
		return old;
		
	}


	/*public void deleteCustDetails(String custid) throws CustException {
		// TODO Auto-generated method stub
		
	}

*/
	


	


	


	



	
}

	
	


