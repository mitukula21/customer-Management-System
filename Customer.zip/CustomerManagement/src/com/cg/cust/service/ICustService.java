package com.cg.cust.service;

import java.util.List;

import com.cg.cust.bean.CustBean;
import com.cg.cust.exception.CustException;

public interface ICustService 
{
	public String addCustDetails(CustBean cust) throws CustException;
	public CustBean editCustDetails(String  custid,String Fname,String eid) throws CustException ;
	public List<CustBean> retriveAll()throws CustException;
	public void deleteCustDetails(int custid) throws CustException;
	public void validateCust(CustBean bean) throws CustException;
}
