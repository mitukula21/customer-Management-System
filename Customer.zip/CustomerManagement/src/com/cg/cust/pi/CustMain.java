package com.cg.cust.pi;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.cust.bean.CustBean;

import com.cg.cust.exception.CustException;
import com.cg.cust.service.CustServiceImpl;

public class CustMain {

	static Scanner sc = new Scanner(System.in);
	
	static CustServiceImpl custServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws CustException {
		PropertyConfigurator.configure("resources//log4j.properties");
		CustBean cust = null;

		String custId = null;
		int option = 0;
		
	try {
		
		System.out.println("Enter UserName: ");
		String user=sc.next();
		System.out.println("Enter password: ");
		String pass=sc.next();
		
		custServiceImpl = new CustServiceImpl();
		
		
	String old=	custServiceImpl.logIn(user);
		
		
		if(old.equals(pass))
		{
	System.out.println("...LOGIN SUCCESSFUL...");

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   CUSTOMER MANAGEMENT SYSTEM ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Customer Page ");
			System.out.println("2.Update/Edit Customer Page");
			System.out.println("3.Customer Listing  Page");
			System.out.println("4.Delete Customer Page");
			System.out.println("5.Exit Application");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (cust == null) {
						cust = populateCustBean();
						       
					}

					try {
						custServiceImpl = new CustServiceImpl();
						custId = custServiceImpl.addCustDetails(cust);

						System.out.println("Customer details  has been successfully registered ");
						System.out.println("Customer  ID Is: " + custId);
						int cus=Integer.parseInt(custId);
						cust.setCustId(cus);
					
					} catch (CustException CustException) {
						logger.error("exception occured", CustException);
						System.err.println("ERROR : "+ CustException.getMessage());
					} finally {
						custId = null;
						custServiceImpl = null;
						cust = null;
					}
        
					break;

				case 2:
   try {
					custServiceImpl = new CustServiceImpl();

					
					CustBean cust1=new CustBean();

					System.out.println("Enter Custid to be edit");
					String cid=sc.next();
					System.out.println("Enter Cust Name to be edit");
					String fname=sc.next();
					System.out.println("Enter Cust Email to be edit");
					String eid=sc.next();
					
					
					custServiceImpl.editCustDetails(cid,fname,eid);
					
					
					System.out.println("updated Successfuly");
						
            }catch(CustException custException) {
		
		    logger.error("Enter Correct Id:", custException);
		       System.err.println("ERROR : "+ custException.getMessage());
	}
	
					break;

				case 3:

					custServiceImpl = new CustServiceImpl();
					try {
						List<CustBean> donorList = new ArrayList<CustBean>();
						donorList = custServiceImpl.retriveAll();

						if (donorList != null) {
							Iterator<CustBean> i = donorList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("Nobody has made a donation, yet.");
						}

					
					}

					catch (CustException e) {

						System.out.println("Error  :" + e.getMessage());
					}
					 
					break;
				case 4:
					try {
					custServiceImpl=new CustServiceImpl();
					CustBean cust2=new CustBean();
					System.out.println("Enter Customer id to be Deleted");
					int cid1=sc.nextInt();
		
					
					custServiceImpl.deleteCustDetails(cid1);
					

					
					
					System.out.println("deleted Successfully");
					}catch(CustException custException) {
						
						logger.error("Enter Correct Id:", custException);
						System.err.println("ERROR : "+ custException.getMessage());
					}
					
					
					break;
				
					
					
					
				case 5:

					System.out.print("Exit customer Application");
					System.exit(0);
					
					break;
				default:
					System.out.println("Enter a valid option[1-5]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}
		}
		
		}
		
	
	else
		{
			System.out.println("enter correct details");
		}
		}catch(Exception e)
		{
			System.out.println("Enter Correct Details");
		}
		
		}
	

	
	
	private static CustBean populateCustBean() {

		// Reading and setting the values for the donorBean
		

		CustBean cust = new CustBean();

		//System.out.println("\n Enter Details");
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter Customer Full name: ");
		cust.setCustName(sc1.nextLine());
		System.out.println("Enter Email Id: ");
		cust.setEmailId(sc.next());

		System.out.println("Enter password: ");
		cust.setPassword(sc.next());

		System.out.println("Enter phone number: ");
		
		try {
			cust.setPhNo(sc.next());
			
		}
		catch(Exception e)
		{
			System.out.println("enter 10 digits only");
		}
		


		Scanner sc2= new Scanner(System.in);
		System.out.println("Enter customer address: ");
		cust.setAddr(sc2.nextLine());	
		Scanner sc3 = new Scanner(System.in);
		System.out.println("Enter city: ");
		cust.setCity(sc3.nextLine());

		System.out.println("Enter Zipcode: ");
		try {
		cust.setZipcode(sc.nextInt());
		}
		catch(Exception e)
		{
			System.out.println("Enter 6 digits only");
		}
		System.out.println("Enter country: ");
		cust.setCountry(sc.next());

		custServiceImpl = new CustServiceImpl();

		try {
			custServiceImpl.validateCust(cust);
			return cust;
		} catch (CustException custException) {
			logger.error("exception occured", custException);
			System.err.println("Invalid data:");
			System.err.println(custException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
