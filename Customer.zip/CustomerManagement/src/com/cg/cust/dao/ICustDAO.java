package com.cg.cust.dao;

import java.util.List;

import com.cg.cust.bean.CustBean;
import com.cg.cust.exception.CustException;

public interface ICustDAO 
{
	public String addCustDetails(CustBean cust) throws CustException;
	public CustBean editCustDetails(int Custid,String fname,String eid) throws CustException;
	public List<CustBean> retriveAllDetails()throws CustException;
	public CustBean deleteCustDetails(String id1) throws CustException;
}
