package com.cg.cust.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.cust.bean.CustBean;

import com.cg.cust.exception.CustException;
import com.cg.cust.util.DBConnection;


public class CustDaoImpl implements ICustDAO 
{
	
	Logger logger=Logger.getRootLogger();
	public CustDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	

	

	public String addCustDetails(CustBean cust) throws CustException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String custId=null;
		
		int queryResult=0;
		System.out.println("connected");
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,cust.getCustName());			
			preparedStatement.setString(2,cust.getEmailId());
			preparedStatement.setString(3,cust.getPassword());
			preparedStatement.setString(4,cust.getPhNo());
			preparedStatement.setString(5,cust.getAddr());
			preparedStatement.setString(6,cust.getCity());
			preparedStatement.setInt(7,cust.getZipcode());
			preparedStatement.setString(8,cust.getCountry());
		//	preparedStatement.setInt(9,cust.getCustId());
					
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.CUSTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				custId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new CustException("Inserting customer details failed ");

			}
			else
			{
				logger.info("customer details added successfully:");
				return custId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CustException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustException("Error in closing db connection");

			}
		}
		
		
	}

	
	public CustBean editCustDetails(int custid,String fname,String eid) throws CustException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		int resultset ;
		CustBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_UPDATE_QUERY);
			preparedStatement.setString(1,fname);
			preparedStatement.setString(2,eid);
			
			preparedStatement.setInt(3,custid);
			resultset=preparedStatement.executeUpdate();
	if(resultset==0)
			throw new CustException("Id doesn't Exist");
			
			
		}
			
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new CustException(e.getMessage());
		}
		finally
		{
			try 
			{
				//resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustException("Error in closing db connection");

			}
		}
		return bean;
		
	}


	public List<CustBean> retriveAllDetails() throws CustException {
		
		Connection con=DBConnection.getInstance().getConnection();
		int donorCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<CustBean> donorList=new ArrayList<CustBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				CustBean bean=new CustBean();
				bean.setCustId(resultset.getInt(1));
				bean.setCustName(resultset.getString(2));
				bean.setEmailId(resultset.getString(3));
				bean.setPassword(resultset.getString(4));
				bean.setPhNo(resultset.getString(5));
				bean.setAddr(resultset.getString(6));
				bean.setCity(resultset.getString(7));
				bean.setZipcode(resultset.getInt(8));
				bean.setCountry(resultset.getString(9));
				bean.setDate(resultset.getDate(10));
				
				
				donorList.add(bean);
				
				donorCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new CustException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustException("Error in closing db connection");

			}
		}
		
		if( donorCount == 0)
			return null;
		else
			return donorList;
	}




	public CustBean deleteCustDetails(String id1) throws CustException{

		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		int resultset ;
		CustBean bean=null;
		try
		{
			int id=Integer.parseInt(id1);
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_DELETE_QUERY);
			preparedStatement.setInt(1,id);
		
			resultset=preparedStatement.executeUpdate();
			
			if(resultset==0)
			{
				//System.out.println("deleted Successfully");
				throw new CustException("deleted id not found");
				
			}
			
			}catch (Exception sqlException) {
				logger.error(sqlException.getMessage());
				
				throw new CustException("deleted id not found");
			}
		
		
		finally
		{
			try 
			{
				//resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustException("Error in closing db connection");

			}
		
		}
	
			return bean;
	
		
		
		
	}




	public String logIn(String user) throws CustException {
Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		CustBean bean=null;
		String old=null;
		try
		{
			
			preparedStatement=connection.prepareStatement(QueryMapper.LOGIN_QUERY);
			preparedStatement.setString(1,user);
			resultset=preparedStatement.executeQuery();
			while(resultset.next())
			{
				 old = resultset.getString(1);
			}
		}catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new CustException(e.getMessage());
		
			
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustException("Error in closing db connection");

			}
		}
		return old;
	}




	










	

}
