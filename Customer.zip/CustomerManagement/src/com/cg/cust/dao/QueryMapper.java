package com.cg.cust.dao;

public interface QueryMapper {
	
	public static final String RETRIVE_ALL_QUERY="SELECT * FROM Customer";
	public static final String VIEW_UPDATE_QUERY="UPDATE Customer set FNAME=? , EMAIL=? where custid=?";
	public static final String INSERT_QUERY="INSERT INTO Customer VALUES(custid_sequence.NEXTVAL,?,?,?,?,?,?,?,?,SYSDATE)";
	public static final String CUSTID_QUERY_SEQUENCE="SELECT custid_sequence.CURRVAL FROM DUAL";
	public static final String VIEW_DELETE_QUERY="delete from Customer where custid=?";
	public static final String LOGIN_QUERY="select password from login where username=?";
	
}
