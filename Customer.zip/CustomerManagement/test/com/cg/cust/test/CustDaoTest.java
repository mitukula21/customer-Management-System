package com.cg.cust.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.cust.bean.CustBean;
import com.cg.cust.dao.CustDaoImpl;
import com.cg.cust.exception.CustException;

public class CustDaoTest {

	static CustDaoImpl dao;
	static CustBean cust;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new CustDaoImpl();
		cust = new CustBean();
	}

	@Test
	public void testAddCustDetails() throws CustException {

		assertNotNull(dao.addCustDetails(cust));

	}

	/************************************
	 * Test case for addCustDetails()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddCustDetails1() throws CustException {
		// increment the number next time you test for positive test case
		assertEquals(1001, dao.addCustDetails(cust));
	}

	/************************************
	 * Test case for addCustDetails()
	 * 
	 ************************************/

	@Test
	public void testAddCustDetails2() throws CustException {

		cust.setCustName("ShashwathiNew");
		cust.setPhNo("7801111231");
	//donor.setPdesc("whitefieldVydehi");
		//donor.setAge(120);
		assertEquals(1001, dao.addCustDetails(cust));
		/*assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addDonorDetails(donor)) > 1000);*/

	}

	/********************************************
	 * Test case for retriveAllDetails()
	 ************************************************/
	@Test
	public void testViewAll() throws CustException {
		assertNotNull(dao.retriveAllDetails());
	}

	/****************************************************
	 * Test case for viewById()
	 ******************************************************/

	@Test
	public void testById() throws CustException {
		assertNotNull(dao.editCustDetails(10,"abc","abc@gmail.com"));
	}

	@Ignore
	@Test
	public void testById1() throws CustException {
		assertEquals("TestName", dao.editCustDetails(10,"abc","abc@gmail.com").getCustName());
	}

}
